import{j as r}from"./index-TwdfaXd4.js";const e=()=>r.jsx("div",{children:"AdminProfile"});export{e as default};
