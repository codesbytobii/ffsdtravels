import{c as o,r,j as s,k as i,Y as l}from"./index-TwdfaXd4.js";import{C as g}from"./chevron-left-BAFd-DeY.js";/**
 * @license lucide-react v0.381.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=o("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.381.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=o("Luggage",[["path",{d:"M6 20h0a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h0",key:"1h5fkc"}],["path",{d:"M8 18V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v14",key:"1l99gc"}],["path",{d:"M10 20h4",key:"ni2waw"}],["circle",{cx:"16",cy:"20",r:"2",key:"1vifvg"}],["circle",{cx:"8",cy:"20",r:"2",key:"ckkr5m"}]]),m=({className:e,...a})=>s.jsx("nav",{role:"navigation","aria-label":"pagination",className:i("mx-auto flex w-full justify-center",e),...a});m.displayName="Pagination";const h=r.forwardRef(({className:e,...a},n)=>s.jsx("ul",{ref:n,className:i("flex flex-row items-center gap-1",e),...a}));h.displayName="PaginationContent";const x=r.forwardRef(({className:e,...a},n)=>s.jsx("li",{ref:n,className:i("",e),...a}));x.displayName="PaginationItem";const t=({className:e,isActive:a,size:n="icon",...c})=>s.jsx("a",{"aria-current":a?"page":void 0,className:i(l({variant:a?"outline":"ghost",size:n}),e),...c});t.displayName="PaginationLink";const d=({className:e,...a})=>s.jsxs(t,{"aria-label":"Go to previous page",size:"default",className:i("gap-1 pl-2.5",e),...a,children:[s.jsx(g,{className:"h-4 w-4"}),s.jsx("span",{children:"Previous"})]});d.displayName="PaginationPrevious";const u=({className:e,...a})=>s.jsxs(t,{"aria-label":"Go to next page",size:"default",className:i("gap-1 pr-2.5",e),...a,children:[s.jsx("span",{children:"Next"}),s.jsx(p,{className:"h-4 w-4"})]});u.displayName="PaginationNext";export{P as L,m as P,h as a,x as b,d as c,t as d,u as e};
