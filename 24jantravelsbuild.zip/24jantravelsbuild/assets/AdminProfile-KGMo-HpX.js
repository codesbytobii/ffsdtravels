import{j as r}from"./index-DBncHmhw.js";const e=()=>r.jsx("div",{children:"AdminProfile"});export{e as default};
